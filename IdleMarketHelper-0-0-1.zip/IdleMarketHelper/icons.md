# Placeholder icon files

# In a real extension, you would have:

# - icon16.png (16x16 pixels)

# - icon48.png (48x48 pixels)

# - icon128.png (128x128 pixels)

# For now, Chrome will use a default icon
